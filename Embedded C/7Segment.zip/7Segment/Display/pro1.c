#include <REG51F.H>
sbit sl1=P2^0;
sbit sl2=P2^1;
sbit sl3=P2^2;
sbit sl4=P2^3;
void display();
void delay(unsigned int t);
void main()
{
P0=0x00;
display();
}
void display()
{
while(1)
{
sl1=0;
sl2=1;
sl3=1;
sl4=1;
P0=0xfc;
delay(4);
sl1= 1;
sl2= 0;
sl3= 1;
sl4= 1;
P0=0x9c;
delay(4);
sl1= 1;
sl2= 1;
sl3= 0;
sl4= 1;
P0=0x9e;
delay(4);
sl1=1;
sl2=1;
sl3=1;
sl4=0;
P0=0x7a;
delay(4);
}
}
void delay(unsigned int t)
{
unsigned int i, j;
for(i=0;i<=t; i++)
{
for(j=0;j<=120; j++);
}
} 


