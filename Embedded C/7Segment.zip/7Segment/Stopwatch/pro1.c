#include <REG51F.H>
sbit sl1=P2^0;
sbit sl2=P2^1;
sbit sl3=P2^2;
sbit sl4=P2^3;	   
sbit dot=P0^0;
void delay(unsigned int t);
void incr();
void display();
unsigned char ds1='0';					  
unsigned char ds2='0';
unsigned char ds3='0';
unsigned char ds4='0';
unsigned int i, j, k;
unsigned int lukup[]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6};
void main()
{
P0=0x00;
while(1)
{
for(k=0; k<=10; k++)
{
display();
}
incr();
}
}
void display()
{
sl1=0;
sl2=1;
sl3=1;
sl4=1;
P0=lukup[ds1-'0'];
delay(45);
sl1=1;
sl2=0;
sl3=1;
sl4=1;
P0=lukup[ds2-'0'];
delay(45);
sl3=0;
sl4=1;
sl1=1;
sl2=1;
P0=lukup[ds3-'0'];
dot=1;
delay(45);
sl4=0;
sl3=1;
sl2=1;
sl1=1;
P0=lukup[ds4-'0'];
delay(45);
}
void incr()
{
ds1++;
if(ds1=='9'+1)
{
ds1='0';
ds2++;
}
if(ds2=='5'+1)
{
ds2='0';
ds3++;
}
if(ds4<='0'+1)
{
   if(ds3=='9'+1)
   {
   ds3='0';
   ds4++;
	}
}
else if(ds4=='1'+1)
{
if(ds3=='3'+1)
{
ds3='0';
ds2='0';
ds1='0';
ds4='0';
}
}
}
void delay(unsigned int t)
{
for(i=0; i<=t; i++)
{
for(j=0; j<=10; j++) ;
}
}
