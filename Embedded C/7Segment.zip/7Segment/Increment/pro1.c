#include <REG51F.H>
void delay(unsigned int t);
unsigned int i, j, k;
void display();
void incr();
sbit sl1 =P2^0;
sbit sl2 =P2^1;
sbit sl3 =P2^2;
sbit sl4 =P2^3;
unsigned char ds1=0, ds2=0, ds3=0, ds4=0;
unsigned int luk[10]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xe6};
void main()
{
while(1)
{
P0=0x00;
for(k=0; k<= 10; k++)
{
display();
}
incr();
}
}
void display()
{
sl1=0;
sl2=1;
sl3=1;
sl4=1;
P0=luk[ds1];
delay(4);
sl2=0;
sl1=1;
sl3=1;
sl4=1;
P0=luk[ds2];
delay(4);
sl3=0;
sl1=1;
sl2=1;
sl4=1;
P0=luk[ds3];
delay(4);
sl4=0;
sl2=1;
sl3=1;
sl1=1;
P0=luk[ds4];
delay(4);
}
void incr()
{
ds1++; 
if (ds1==9+1)
	{
	ds1=0;
	ds2++;
		if(ds2==9+1)
			{
			ds2=0;
			ds3++;
			if (ds3==9+1)
				{
				ds3=0;
				ds4++;
				if (ds4==9+1)
					{
					ds1=0;
					ds2=0;
					ds3=0;
					ds4=0;
					}
				}
			}
	}
}


void delay(unsigned int t)
{
for(i=0; i<=t; i++)
{
for(j=0; j<=120; j++);
}
}

