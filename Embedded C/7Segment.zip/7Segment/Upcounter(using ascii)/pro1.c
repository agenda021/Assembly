#include <REG51F.H>
sbit sl1= P2^0;
sbit sl2= P2^1;
sbit sl3= P2^2;
sbit sl4= P2^3;
void delay(unsigned int t);
void display();
void incr();
unsigned int i, j, k;
unsigned char ds1='0';					  
unsigned char ds2='0';
unsigned char ds3='0';
unsigned char ds4='0';
unsigned int lukup[]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e};
void main()
{
P0=0x00;
ds1='0';
while(1)
{
for(k=0; k<=22; k++)
{
display();
}
incr();
}
}
void display()
{
sl1=0;
sl2=1;
sl3=1;
sl4=1;
P0=lukup[ds1-'0'];
delay(5);
sl1=1;
sl2=0;
sl3=1;
sl4=1;
P0=lukup[ds2-'0'];
delay(5);
sl3=0;
sl4=1;
sl1=1;
sl2=1;
P0=lukup[ds3-'0'];
delay(5);
sl4=0;
sl3=1;
sl2=1;
sl1=1;
P0=lukup[ds4-'0'];
delay(5);
}
void incr()
{
ds1++;
if(ds1=='9'+1)
{
ds1='A';
}
if(ds1=='F'+1)
{
ds1='0';
ds2++;
}
if(ds2=='9'+1)
{
ds2='A';
}
if(ds2=='F'+1)
{
ds2='0';
ds3++;
}
if(ds3=='9'+1)
{
ds3='A';
}
if(ds3=='F'+1)
{
ds3='0';
ds4++;
}
if(ds4=='9'+1)
{
ds4='A';
}
if(ds4=='F'+1)
{
ds1='0';
ds2='0';
ds3='0';
ds4='0';
}
}
void delay(unsigned int t)
{
for(i=0; i<=t; i++)
{
for(j=0; j<=100; j++) ;
}
}
