#include <REG51F.H>
sbit sl1=P2^0;
sbit sl2=P2^1;
sbit sl3=P2^2;
sbit sl4=P2^3;
void delay(unsigned int t);
void display();
void decr();
unsigned int i, j, k;
unsigned char ds1='F';
unsigned char ds2='F';
unsigned char ds3='F';
unsigned char ds4='F';
unsigned int lukup[]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e};
void main()
{
P0=0x00;
while(1)
{
for(k=0; k<=22; k++)
{
display();
}
decr();
}
}
void display()
{
sl1=0;
sl2=1;
sl3=1;
sl4=1;
P0=lukup[ds1-'0'];
delay(5);
sl2=0;
sl1=1;
sl3=1;
sl4=1;
P0=lukup[ds2-'0'];
delay(5);
sl1=1;
sl2=1;
sl3=0;
sl4=1;
P0=lukup[ds3-'0'];
delay(5);
sl1=1;
sl2=1;
sl3=1;
sl4=0;
P0=lukup[ds4-'0'];
delay(5);
}
void decr()
{
ds1--;
if(ds1=='A'-1)
{
ds1='9';
}
if(ds1=='0'-1)
{
ds1='F';
ds2--;
}
if(ds2=='A'-1)
{
ds2='9';
}
if(ds2=='0'-1)
{
ds2='F';
ds3--;
}
if(ds3=='A'-1)
{
ds3='9';
}
if(ds3=='0'-1)
{
ds3='F';
ds4--;
if(ds4=='A'-1)
{
ds4='9';
}
if(ds4=='0'-1)
{
ds4='F';
ds3='F';
ds2='F';
ds1='F';
}
}
}
void delay(unsigned int t)
{
for(i=0; i<=t; i++)
{
for(j=0; j<=100; j++);
}
}

