#include <REG51F.H>

sbit sl1=P2^0;
sbit sl2=P2^1;
sbit sl3=P2^2;
sbit sl4=P2^3;

sbit krl1=P2^4;
sbit krl2=P2^5;
sbit krl3=P2^6;
sbit krl4=P2^7;

sbit buzz=P1^5;

bit nkp;
bit tb;
bit start_buzzer;
bit key_ready;
bit ovr_bit;

unsigned int i, j;
unsigned char dcount, krcount, key_code, scan, start_count;
unsigned char ds1, ds2, ds3, ds4, delay_reg;
unsigned char lut[]={0xfc, 0x60, 0xda, 0xf2,0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e};

void delay();
void isr_t0(void);
void process();
void incr();
void scanner();
void init_t0();
void init_keypad();
void key_release();
void key(void);
void debounce();
void display();
code unsigned char lut_ascii[]={'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A','B','C','D','E','F'};

void main()
{
P0=0x00;
init_t0();
init_keypad();
EA=1;
ds1=ds2=ds3=ds4='0';
while(1)
{
while(key_ready==1)
{
process();
key_release();
}
}
}

void init_t0()
{

TMOD=0x01;
TH0=0xF2;
TL0=0xF2;	
TR0=1;
ET0=1;
   

}

void isr_t0(void)interrupt 1 using 1  //interrupt 1 mode 1
{
	delay();//to enable ovr bit 
	init_t0();
	if(start_buzzer==1)
    buzz=~(buzz);
	scanner();
	if(ovr_bit==1)
	{
		incr();
		ovr_bit=0;
	}
}

void init_keypad()
{
key_code=0;
scan=0;
krcount=32;
dcount=33;
key_ready=0;
nkp=0;
start_buzzer=0;
}

void scanner()
{
if(scan==0)
{
sl1=0;
sl2=sl3=sl4='1';
P0=lut[ds1-'0'];
tb=krl1;
key();
scan++;
 }
 if(scan==1)
 { tb=krl2;
 key();
 scan++;
 }

 if(scan==2)
 tb=krl3;
 key();
 scan++;

 if(scan==3)
 {
 tb=krl4;
 key();
 scan++;
 P0=0x00;
 }

 if(scan==4)
 {
 sl2=0;
 sl1=sl3=sl4=2;
 P0=lut[ds2-'0'];
 tb=krl1;
 key();
 scan++;
 }

 if(scan==5)
 {
 tb=krl2;
 key();
 scan++;
 }

 if(scan==6)
 {
 tb=krl3;
 key();
 scan++;
 }

 if(scan==7)
 {
 tb=krl4;
 key();
 scan++;
 P0=0x00;
 }


 if(scan==8)
 {
 sl3=0;
 sl1=sl2=sl4=1;
 P0=lut[ds3-'0'];
 tb=krl1;
 key();
 scan++;
 }
 if(scan==9)
 {
 tb=krl2;
 key();
 scan++;
 }

if(scan==10)
{
tb=krl3;
key();
scan++;
}

if(scan==11)
{
tb=krl4;
key();
scan++;
P0=0x00;
}

if(scan==12)
{
sl4=0;
sl2=sl3=sl1=1;
P0=lut[ds4-'0'];
tb=krl1;
key();
scan++;
}

if(scan==13)
{
tb=krl2;
key();
scan++;
}

if(scan==14)
{
tb=krl3;
key();
scan++;
}

if(scan==15)
{
tb=krl4;
key();
scan=0;
P0=0x00;
}
}


void key()
{
if(key_ready==0)
{
if(dcount==33)
{
if(tb==0)
{
key_code=scan;
dcount--;
}
else
dcount--;
}
else
{
dcount--;
if(dcount==0)
{
if(tb==0)
{
key_ready=start_buzzer=1;
dcount=33;
}
else
dcount=33;
}
}
}
else
{
debounce();
}
}

void debounce()
{
krcount--;
if(krcount==0)
{
if(tb==1)
{
nkp=1;
start_buzzer=0;
krcount=32;
}
else
krcount=32;
}
}

void key_release()
{
while(nkp==0)
{}
key_ready=0;
nkp=0;
}

void process()
{
if(lut_ascii[key_code]=='A')
{
start_count=1;
incr();
}
if (lut_ascii[key_code]=='B')
{
start_count=0;
incr();
}
if (lut_ascii[key_code]=='C')
{
ds1='0';
ds2='0';
ds3='0';
ds4='0';
}
  }
void incr()
 {
 if(start_count==1)
 {
ds1++;
if(ds1=='9'+1)
{
ds1='0';
ds2++;
}
if(ds2=='5'+1)
{
ds2='0';
ds3++;
}
if(ds4<='0'+1)
{
   if(ds3=='9'+1)
   {
   ds3='0';
   ds4++;
	}
}
else if(ds4=='1'+1)
{
if(ds3=='3'+1)
{
ds3='0';
ds2='0';
ds1='0';
ds4='0';
}
}
}
} 

void delay()
{
	delay_reg--;
	if(delay_reg==0x00)
	{
		delay_reg=0x0f;
		ovr_bit=1;
	}
}
