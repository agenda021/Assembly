#include <REG51F.H>
#include <intrins.h>
sbit sl1 = P2^0;
sbit sl2 = P2^1;
sbit sl3 = P2^2;
sbit sl4 = P2^3;
sbit krl1= P2^4;
sbit krl2= P2^5;
sbit krl3= P2^6;
sbit krl4= P2^7;

unsigned char ds1;
unsigned char look_up[]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e};

void main()
{
while(1)
{
P0=0x00;
sl1=0;
sl2=sl3=sl4=1;

if(krl1==0)
ds1=0;
else if(krl2==0)
ds1=1;
else if(krl3==0)
ds1=2;
else if(krl4==0)
ds1=3;

P0=0x00;
sl2=0;
sl1=sl3=sl4=1;
P0=look_up[ds1];
if(krl1==0)
ds1=4;
else if(krl2==0)
ds1=5;
else if(krl3==0)
ds1=6;
else if(krl4==0)
ds1=7;

P0=0x00;
sl3=0;
sl1=sl2=sl4=1;
if(krl1==0)
ds1=8;
else if(krl2==0)
ds1=9;
else if(krl3==0)
ds1=10;
else if(krl4==0)
ds1=11;

P0=0x00;
 sl4=0;
sl1=sl2=sl3=1;
if(krl1==0)
ds1=12;
else if(krl2==0)
ds1=13;
else if(krl3==0)
ds1=14;
else if(krl4==0)
ds1=15;
}
}
