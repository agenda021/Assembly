#include <REG51F.H>
#include <intrins.H>

sbit sl1=P2^0;
sbit sl2=P2^1;
sbit sl3=P2^2;
sbit sl4=P2^3;

sbit krl1=P2^4;
sbit krl2=P2^5;
sbit krl3=P2^6;
sbit krl4=P2^7;

sbit back=P0^0;
sbit rs  =P0^1;
sbit rw  =P0^2;
sbit en  =P0^3;
sbit d4  =P0^4;
sbit d5  =P0^5;
sbit d6  =P0^6;
sbit d7  =P0^7;

sbit buzz=P1^5;

bit nkp, tb, start_buzzer, key_ready, ovr_bit;

unsigned int i,j,k;
unsigned char dcount, krcount, key_code, scan, start_count;
unsigned char ds1, ds2, ds3, ds4, delay_reg;
unsigned char lut[]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xee, 0x3e, 0x9c,0x7a, 0x9e, 0x8e};

void delay1();
void isr_t0(void);
void lcd_disp();
void lcd_cw(unsigned char);
void lcd_dw(unsigned char);
void disp_sw();
void delay(unsigned int t);
void toggle_e();
void process();
void incr();          
void scanner();
void init_t0();
void init_keypad();
void key_release();
void init_lcd ();
void key();
void debounce();
void display();
unsigned char lut_ascii[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
unsigned char luk_up[10]={"0123456789"};
void main()
{
P0=0x00;
init_lcd();
init_t0();

init_keypad();
EA=1;
disp_sw();

ds1=ds2=ds3=ds4=0;
lcd_disp();
delay(5);
while(1)		
{
while(key_ready==1)
{
process();
key_release();
}
}
}
void lcd_disp()
{
lcd_cw(0xc5);
delay(1);
lcd_dw(luk_up[ds4]);
delay(1);
lcd_dw(luk_up[ds3]);
delay(1);
lcd_dw(':');
delay(1);
lcd_dw(luk_up[ds2]);
delay(1);
lcd_dw(luk_up[ds1]);
delay(1);
}


void disp_sw()
{
lcd_cw(0x80);
delay(10);    
	delay(1);
	lcd_dw('S');
	delay(1);
	lcd_dw('T');
	delay(1);
	lcd_dw('O');
	delay(1);
	lcd_dw('P');
	delay(1);
	lcd_dw('W');
	delay(1);
	lcd_dw('A');
	delay(1);
	lcd_dw('T');
	delay(1);
                     lcd_dw('C');
	delay(1);
	lcd_dw('H');
	delay(1);
	lcd_dw(':');
	delay(1);
	lcd_dw('-');
	delay(1);
	lcd_dw('A');
	delay(1);
	lcd_dw(',');
	delay(1);
	lcd_dw('B');
	delay(1);
	lcd_dw(',');
	delay(1);
	lcd_dw('C');
	delay(1);
}
   
void init_lcd()
{
delay(15);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);
lcd_cw(0x02); // 4 bit mode
delay(5);
lcd_cw(0x28); // set interface length
delay(5);
lcd_cw(0x10);  // move cursor shift display
delay(5);
lcd_cw(0x0e); // enable display cursor
delay(5);
lcd_cw(0x06); // cursor move direction
delay(5);
lcd_cw(0x01); // clear display
delay(5);
//back=1;
}

void lcd_cw(unsigned char x)
{
rs=0;
rw=0;
P0=((P0&0x0f)|(x&0xf0));
toggle_e();
P0=((P0&0x0f)|((x<<4)&0xf0));
toggle_e();
}

void lcd_dw(unsigned char x)
{
rs=1;
rw=0;
P0=((P0&0x0f)|(x&0xf0));
toggle_e();
P0=((P0&0x0f)|((x<<4)&0xf0))	;
toggle_e();
}


void toggle_e()
{
en=1;
_nop_();
_nop_();
_nop_();
_nop_();
en=0;
_nop_();
_nop_();
}




void init_t0()
{
TMOD=0x01;
TH0=0xF2;
TL0=0xF2;
TR0=1;
ET0=1;
}

void isr_t0(void)interrupt 1 using 1  //interrupt 1 mode 1
{
	delay1();//to enable ovr bit 
	init_t0();
	if(start_buzzer==1)
    buzz=~(buzz);
	scanner();
	if(ovr_bit==1)
	{
		incr();
		lcd_disp();
		ovr_bit=0;
	}
}

void init_keypad()
{
krl1=krl2=krl3=krl4=1;
key_code=0;
scan=0;
krcount=32;
dcount=33;
key_ready=0;
nkp=0;
start_buzzer=0;
}
void scanner()
{
if(scan==0)
{
sl1=0;
sl2=sl3=sl4=1;
P0=lut[ds1-'0'];
tb=krl1;
key();
scan++;
}
if(scan==1)
{
tb=krl2;
key();
scan++;
}
if(scan==2)
{
tb=krl3;				 
key();
scan++;
}
if(scan==3)
{
tb=krl4;
key();
scan++;
P0=0x00;
} 
 if(scan==4)
 {
 sl2=0;
 sl1=sl3=sl4=2;
 P0=lut[ds2-'0'];
 tb=krl1;
 key();
 scan++;
 }

 if(scan==5)
 {
 tb=krl2;
 key();
 scan++;
 }

 if(scan==6)
 {
 tb=krl3;
 key();
 scan++;
 }

 if(scan==7)
 {
 tb=krl4;
 key();
 scan++;
 P0=0x00;
 }


 if(scan==8)
 {
 sl3=0;
 sl1=sl2=sl4=1;
 P0=lut[ds3-'0'];
 tb=krl1;
 key();
 scan++;
 }
 if(scan==9)
 {
 tb=krl2;
 key();
 scan++;
 }

if(scan==10)
{
tb=krl3;
key();
scan++;
}

if(scan==11)
{
tb=krl4;
key();
scan++;
P0=0x00;
}

if(scan==12)
{
sl4=0;
sl2=sl3=sl1=1;
P0=lut[ds4-'0'];
tb=krl1;
key();
scan++;
}

if(scan==13)
{
tb=krl2;
key();
scan++;
}

if(scan==14)
{
tb=krl3;
key();
scan++;
}

if(scan==15)
{
tb=krl4;
key();
scan=0;
P0=0x00;
}
}
void key()
{
if(key_ready==0)
{
if(dcount==33)
{
if(tb==0)
{
key_code=scan;
dcount--;
}
else
dcount--;
}
else
{
dcount--;
if(dcount==0)
{
if(tb==0)
{
key_ready=start_buzzer=1;
dcount=33;
}
else 
dcount=33;
}
}
}
else
{
debounce();
}
}
void debounce()
{
krcount--;
if(krcount==0)
{
if(tb==1)
{
nkp=1;
start_buzzer=0;
krcount=32;
}
else
krcount=32;
}
}

void key_release()
{
while(nkp==0)
{}
key_ready=0;
nkp=0;
}

void process()
{
if(lut_ascii[key_code]=='A')

start_count=1;
else
{
if (lut_ascii[key_code]=='B')

start_count=0;
else
{
if (lut_ascii[key_code]=='C')
{
start_count=0;
ds1=0;
ds2=0;
ds3=0;
ds4=0;
}
}
 }
  }
void incr()
{
	if(start_count==1)
	{
		ds1++;
		if(ds1==9+1)
		{
			ds1=0;
			ds2++;
			if(ds2==9+1)
			{
				ds2=0;
				ds3++;
				if(ds3==9+1)
				{
					ds3=0;
					ds4++;
					if(ds4==9+1)
						ds4=0;
				}
			}
		}
	}
}

void delay1()
{
	delay_reg--;
	if(delay_reg==0x00)
	{
		delay_reg=0x0f;
		ovr_bit=1;
	}
}
void delay(unsigned int t)
{
unsigned int i, j;
for(i=0; i<=t; i++)
{
for(j=0; j<=120; j++);
}
}