#include <REG51F.H>
unsigned int i, j;
void delay(unsigned int t);
void main()
{
while(1)
{
P0=0x00;
while(P0<0xff)
{
delay(100);
P0++;
}
while(P0>0x00)
{
delay(100);
P0--;
}
}
}
 void delay(unsigned int t)
 {
 for(i=0;i<=t; i++)
 {
 for(j=0; j<=120; j++);
 }
 }