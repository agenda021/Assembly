 /* Program to blink 2 leds with 2 interrupts */

#include <REG51F.H>

sbit led1=P0^0;
sbit led2=P0^7;

unsigned int count1=50, count2=30;
void init_t0();
void init_t1();

void isr_t0(void) interrupt 1 using 1 //interrupt 1 mode 1
{
 init_t0();
 count1--;
 if(count1==0)
 {
 led1=~led1;
 count1=50;
 }
 }

 void isr_t1(void) interrupt 3 using 1
 {
 init_t1();
 count2--;
 if(count2==0)
 {
 led2=~led2;
 count2=30;
 }
 }

 void main()
 {
 P0=0x00;
 TMOD=0x11; // timers to work;  combine and provide tmod =0001 0001
 led1=1;
 led2=1;
 init_t0();
 init_t1();
 EA=1;
 while(1);
 }

 void init_t0()
 {
 TH0=0x20;
 TL0=0xFF;
 TR0=1;
 ET0=1;
 }

 void init_t1()
 {
 TH1=0x4B;
 TL1=0xFE;
 TR1=1;
 ET1=1;
 }
