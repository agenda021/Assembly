/* Two Led blink using timer delay */

#include <REG51F.H>
//declarations
sbit led1=P0^7;
sbit led2=P0^5;
unsigned int i, j;
void init_t0();

void main()
{
P0=0x00;
while(1)
{
led1=1;
led2=1;
init_t0();
led1=0;
led2=0;
init_t0();
}
}
void init_t0()
{
TMOD=0x01; //timer0, mode1
TH0=0x10;
TL0=0x00;
TR0=1;  //start timer
while(!TF0);	// When tf0 is overcomplemented come out of loop
//TRO=0
TF0=0;	  // clear TFO when the delay is complete
}