/* program to blink leds at 2 different rates by using 2 timers */
#include <REG51F.H>

sbit led1=P0^0;
sbit led2=P0^7;

void timer_0();
void timer_1(unsigned int t);

void main()
{
P0=0x00;
while(1)
{
timer_0();
led1=~led1;
timer_1(1);
led2=~led2;
timer_1(1);
}
}

void timer_0()
{
TMOD=0x01;
TH0=0x10;
TL0=0x00;
TR0=1;
while(!TF0);
TF0=0;
}

void timer_1(unsigned int t)
{
unsigned int i;
for(i=0; i<=t; i++)
{
 TMOD=0x10;
 TH1=0x70;
 TL1=0x70;
 TR1=1;
 while(!TF1);
 TF1=0;
 }
 }


