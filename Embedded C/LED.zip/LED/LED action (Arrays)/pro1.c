#include <REG51F.H>
 void delay(unsigned int t);
 unsigned int i, j, k;
 unsigned int ACT1[]={ 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
 unsigned int ACT2[]={ 0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
 unsigned int ACT3[]={ 0x55, 0xaa};
 void main()
 {
 for(k=0; k<=7;k++)
 {
 P0=ACT1[k];
 delay(200);
 }
 for(j=0; j<=7; j++)
 {
 P0=ACT2[j];
 delay(200);
 }
 for(i=0; i<=1; i++)
 {
 P0=ACT3[i];
 delay(200);
 }
 }
 void delay(unsigned int t)
 {
 unsigned int i, j;
 for(i=0; i<=t; i++)
 {
 for(j=0; j<=200; j++);
 }
 }