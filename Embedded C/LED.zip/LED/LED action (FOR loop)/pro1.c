#include <REG51F.H>
unsigned int i, k, l, rot=0x03; 
void delay(unsigned int t);
void Action1();
void Action2();
 void Action3();


void main()
{ 
while(1)
{
Action1();
 Action2();
 Action3();
}
}
void Action1()

{

for(i=0; i<=rot; i++)
{
P0=0x01;
delay(150);
P0=0x02;
delay(150);
P0=0x04;
delay(150);
P0=0x08;
delay(150);
P0=0x10;
delay(150);
P0=0x20;
delay(150);
P0=0x40;
delay(150);
P0=0x80;
delay(150);

}
}
   void Action2()

{

for(i=0; i<=rot; i++)
{
P0=0x00;
delay(150);
P0=0x81;
delay(150);
P0=0x42;
delay(150);
P0=0x24;
delay(150);
P0=0x18;
delay(150);
}
}
	 void Action3()

{

for(i=0; i<=rot; i++)
{
P0=0x55;
delay(250);
P0=0xaa;
delay(250);

}
}

void delay(unsigned int t)
{
for(k=0; k<=t; k++)
{
for(l=0; l<=100; l++);
}
}
