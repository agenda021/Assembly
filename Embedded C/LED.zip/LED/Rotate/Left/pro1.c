#include <REG51F.H>
unsigned int i, j;
void delay(unsigned int t);
void main()
{
while(1)
{
 P0=0x01;
while(P0<0x80)
{
	 delay(200);
P0=P0<<1;
delay(200);
}
}
}
void delay(unsigned int t)
{
for(i=0;i<t; i++)
{
for(j=0; j<500; j++);
}
}
