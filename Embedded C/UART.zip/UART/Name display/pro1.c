#include <REG51F.H>
void init_uart();
void tx(unsigned char ch2);
unsigned char rx();
unsigned char ch, ch1;
unsigned int i, j;
void delay(unsigned int n);

void main()
{
init_uart();
tx('J');
delay(100);
tx('E');
delay(100);
tx('S');
delay(100);
tx('U');
delay(100);
tx('S');
delay(100);
tx(' ');
delay(100);
tx('C');
delay(100);
tx('H');
delay(100);
tx('R');
delay(100);
tx('I');
delay(100);
tx('S');
delay(100);
tx('T');
delay(100);
while(1)
{
ch=rx();
tx(ch);
}
}
void init_uart()
{
SCON=0x52;
TMOD=0x20;
TH1=0xfd;
TR1=1;
}

void tx(unsigned char ch2)
{
while(TI==0);
SBUF=ch2;
TI=0;
}

unsigned char rx()
{
while(RI==0);
ch1=SBUF;
RI=0;
return(ch1);
}

void delay(unsigned int n)
{
for(i=0;i<=n;i++)
{
for(j=0;j<=100;j++);
}
}




