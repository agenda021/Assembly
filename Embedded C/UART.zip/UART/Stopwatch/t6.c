  	#include<Reg51f.h>
	#include<stdio.h>
                  sbit sl1=P2^0;			
	sbit sl2=P2^1;
	sbit sl3=P2^2;
	sbit sl4=P2^3;
	sbit krl1=P2^4;			
	sbit krl2=P2^5;
	sbit krl3=P2^6;
	sbit krl4=P2^7;
	sbit pin15=P1^5;		

	bit key_ready,nkp,start_buzzer,start_sw,s1_over;

	unsigned int count,scan_no,ds1,ds2,ds3,ds4,krcount,dcount,key_code,key_temp,cnt_1sl,cnt_1sh,tx_data;
	unsigned int disp_lut[]={0xfc,0x60,0xda,0xf2,0x66,0xb6,0xbe,0xe0,0xfe,0xe6,0x7c,0x00};
	unsigned char ascii[]="0123456789ABCDEF";
	

	void init();
	void k();
	void init_timer0();
	void init_keypad();
	void scanner();
	void inc_d();
	
	void key_release();
	void buzzer();
	void disp_sw();
	void zero_disp();
	void init_delay_1sec();
	void keyprocess();
	void get_key();
	void process_a();
	void process_b();
	void process_c();
	void delay_1sec();

void uart_init();
void uart_disp();
void uart_tx();
void uart_delay(unsigned int);
	
	void isr_t0() interrupt 1 using 0
	{	
	init_t0();
		delay_1sec();
		buzzer();
		scanner();
		if(s1_over==1)
		{
		 	inc_d();
			s1_over=0;
		}

	}

   	void init_delay_1sec()
	{
		cnt_1sl,0xe8;
		cnt_1sh,0x04;
		s1_over=1;
	}

  void delay_1sec()
	{
	 	if(s1_over==0)	
		{
		 	while(cnt_1sl)
			{
				cnt_1sl--;
				goto out_ds1sec;
			}
			while(cnt_1sh)
			{
				cnt_1sh--;
				goto reinit_1sl; 	
			}

			cnt_1sh=0x04;
			cnt_1sl=0xe8;
			s1_over=1;
		} 
reinit_1sl:
		cnt_1sl=0xff;		

out_ds1sec:;
	
	}


	void main()
	{
		
		init();
		EA=1;
		disp_sw();
		uart_disp();
		uart_delay(500);	

		zero_disp();
		uart_disp();
		
		while(1)
		{
			get_key();
			keyprocess();
			
		}
	
	}
	void zero_disp()
	{
	
		ds1=0;
		ds2=0;
		ds3=0;
		ds4=0;
	}

		

	void init()
	{
		init_timer0();
		uart_init();
		init_keypad();
		init_delay_1sec();
	}


	void init_keypad()
	{
		krl1=1;
		krl2=1;
		krl3=1;
		krl4=1;
		scan_no=0;
		dcount=33;
		krcount=32;
		key_ready=0;
		nkp=0;
		start_buzzer=0;
	}

	void init_timer0()
	{
		TMOD|=0x01;
		TL0=0X66;
		TH0=0Xfc;
		TR0=1;
		ET0=1;
	}
void uart_init()
{
	  TMOD=0x20;
	  TH1=0xFD;
	  TR1=1;
	  SCON=0x52;
}


	void init_delay_1sec()
	{
		cnt_1sl,0xe8;
		cnt_1sh,0x04;
		s1_over=1;
	}

	void delay_1sec()
	{
	 	if(s1_over==0)	
		{
		 	while(cnt_1sl)
			{
				cnt_1sl--;
				goto out_ds1sec;
			}
			while(cnt_1sh)
			{
				cnt_1sh--;
				goto reinit_1sl; 	
			}

			cnt_1sh=0x04;
			cnt_1sl=0xe8;
			s1_over=1;
		} 
reinit_1sl:
		cnt_1sl=0xff;		

out_ds1sec:;
	
	}



	void scanner()
	{
	 	switch(scan_no)

		{
			case 0:
					sl1=0;
					sl2=1;
					sl3=1;
					sl4=1;
					
					CY=krl1;
					k();
					scan_no=1;
					break;	   
	
	
			case 1:
					CY=krl2;
					k();
					scan_no=2;
					break;
	
			case 2: CY=krl3;
					k();
					scan_no=3;
					break;
	
			case 3:
					
					CY=krl4;
					k();
					scan_no=4;
					break;
	
			case 4: 
					sl1=1;
					sl2=0;
					sl3=1;
					sl4=1;
					
					CY=krl1;
					k();
					scan_no=5;
					break;	
	
			case 5: 
					CY=krl2;
					k();
					scan_no=6;
					break;	
	
			case 6: 
					CY=krl3;
					k();
					scan_no=7;
					break;
	
	
			case 7: 
					
					CY=krl4;
					k();
					scan_no=8;
					break;
	
	
			case 8: 
					sl1=1;
					sl2=1;
					sl3=0;
					sl4=1;
					
					CY=krl1;
					k();
					scan_no=9;
					break;
	
	
			case 9: 
					CY=krl2;
					k();
					scan_no=10;
					break;
	
	
			case 10: 
					CY=krl3;
					k();
					scan_no=11;
					break;
	
	
			case 11: 
					
					CY=krl4;
					k();
					scan_no=12;
					break;
		  
	
			case 12: 
					sl1=1;
					sl2=1;
					sl3=1;
					sl4=0;
					
					CY=krl1;
					k();
					scan_no=13;
					break;
	
	
			case 13: 
					CY=krl2;
					k();
					scan_no=14;
					break;
	
	
			case 14: 
					CY=krl3;
					k();
					scan_no=15;
					break;
	
	
			case 15: 
					
					CY=krl4;
					k();
					scan_no=0;
					break;

		    default:scan_no=0;
					break;	
		}
	}
	
void k()
	{
		if(key_ready==1)
			{
				goto debounce;
			}

		else if(key_ready==0)
		{
				if(dcount==33)
				{
					if(CY==1)
					{					
					goto out_k;
					}
					else 
					{
					 	dcount--;
						key_code=scan_no;
						goto out_k;
					}
	
				}
				else if (dcount!=33)
				{
				 	dcount--;
					if (dcount!=0)
					{
					 		goto out_k;
					}
					else if(dcount==0)
					{
						if(CY==0)
						{
						 	key_ready=1;
							start_buzzer=1;
							dcount=33;
							goto out_k;
						}
						else
						{
						 	dcount=33;
							goto out_k;
						}
					}
				}
		   }


	debounce:
	{
	 	if(CY==0)
		{
		 	krcount=32;
			goto out_k;
		}
		else
		{
			krcount--;

			if(krcount==0)
			{
			 nkp=1;
			 start_buzzer=0;
			 krcount=32;
			 goto out_k;
			}

			else
			{
			 	goto out_k;
			}
		}
	}

 	out_k:;

 	} 
	   	

	void disp_sw()
	{
	/*
		ds1=19;
		ds2=18;
		ds3=17;
		ds4=16;

	*/	

	}


	void inc_d()
	{
		if (start_sw==0)
		goto out_id;
		ds1++;
		if (ds1>9)
		  {
			ds1=0;
			ds2++;
			if(ds2>9)
				{
					ds2=0;
					ds3++;
					if(ds3>9)
						{
							ds3=0;
							ds4++;
							if(ds4>9)
								{
									ds1=0;
							       	ds2=0;
									ds3=0;
									ds4=0;
								}
							}
					}
			}
	out_id:;
	uart_disp();
	} 	

	void key_release()
	{
	 	while(nkp==0);
		key_ready=0;
		nkp=0;
	}

	void get_key()
	{
	    
	    
		while(key_ready==0);
		key_temp=key_code;
		key_code=ascii[key_code];

	}
    
	void keyprocess()
	{
	 	if(key_code=='A')
		{
		 	process_a();
			goto out_kp;
		}

		if(key_code=='B')
		{
		 	process_b();
			goto out_kp;
		}

		if(key_code=='C')
		{
		 	process_c();
			goto out_kp;
		}

		key_release();
	
	out_kp:;
	}

	void process_a()
	{
	 	start_sw=1;
	}

	void process_b()
	{
	 	start_sw=0;
	}
	
	void process_c()
	{
	 	start_sw=0;
		ds1=0;
		ds2=0;
		ds3=0;
		ds4=0;
	}

	void buzzer()
	{
	 	if(start_buzzer==1)
		   {
			pin15=~pin15;			
		   }		
	}
void uart_tx()
{  
	while(TI==0);  
    SBUF=tx_data;
	TI=0;
}
void uart_disp()
{
	
	tx_data=ascii[ds4];
	uart_tx();
	tx_data=ascii[ds3];
	uart_tx();
	tx_data=ascii[ds2];
	uart_tx();
	tx_data=ascii[ds1];
	uart_tx();
}

void uart_delay(unsigned int n)
{
		unsigned int k,j;
	
	 	for (k=0;k<=n;k++)
			for (j=0;j<=255;j++);
}

