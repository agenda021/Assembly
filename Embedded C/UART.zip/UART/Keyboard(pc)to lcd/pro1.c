#include <REG51F.H>
sbit VCC=P0^0;
sbit RS=P0^1;
sbit RW=P0^2;
sbit EN=P0^3;
sbit d4=P0^4;
sbit d5=P0^5;
sbit d6=P0^6;
sbit d7=P0^7;

unsigned int i, j,k;
unsigned char ds1, a;
void init_uart();
void init_lcd();
unsigned char rx();
void init_lcd1();
void init_lcd2();
void cmd_wrt(unsigned char c);
void data_wrt(unsigned char d);
void toggle();
void delay(unsigned int t);

void main()
{
init_uart();
init_lcd1();

while(1)
{				  

ds1=rx();
delay(5);
data_wrt(ds1);
delay(5);
}

}

void init_uart()
{
TMOD=0x20;
TH1=0xFD;
TR1=1;
SCON=0x52;

ET1=1;
EA=1;
}

unsigned char rx()
{
while(RI==0);
a=SBUF;
RI=0;
return(a);
}

void init_lcd1()
{
for(k=0; k<=16; k++);
{
cmd_wrt(0x80);
delay(5);
init_lcd();
}
init_lcd2();
}

void init_lcd2()
{
for(k=0; k<=16; k++);
{
cmd_wrt(0xC0);
delay(5);
init_lcd();
}
}

void init_lcd()
{
cmd_wrt(0x03);
delay(5);
cmd_wrt(0x03);
delay(5);
cmd_wrt(0x03);
delay(5);
cmd_wrt(0x02);
delay(5);
cmd_wrt(0x28);
delay(5);
cmd_wrt(0x10);
delay(5);
cmd_wrt(0x0E);
delay(5);
cmd_wrt(0x06);
delay(5);
cmd_wrt(0x01);
delay(5);
VCC=0;
delay(5);
}

void cmd_wrt(unsigned char c)
{
RS=0;
RW=0;
P0=((P0&0x0F)|(c&0xF0));
toggle();
P0=((P0&0x0F)|((c<<4)&0xF0));
toggle();
}

void data_wrt(unsigned char d)
{
RS=1;
RW=0;
P0=((P0&0x0F)|(d&0xF0));
toggle();
P0=((P0&0x0F)|((d<<4)&0xF0));
toggle();
}
void toggle()
{
EN=1;
delay(1);
EN=0;
}

void delay(unsigned int t)
{
int i, j;
for(i=0;i<=t;i++)
{
for(j=0;j<=120;j++);
}
}

