#include <REG51F.H>
#include<stdio.h>
sbit sl1=P2^0;
sbit sl2=P2^1;
sbit sl3=P2^2;
sbit sl4=P2^3;

sbit krl1=P2^4;
sbit krl2=P2^5;
sbit krl3=P2^6;
sbit krl4=P2^7;

sbit buzz=P1^5;

bit nkp;
//bit tb;
bit start_buzzer;
bit key_ready;



unsigned int tx_data, count, dcount, krcount, key_code, scan, start_count;
unsigned int ds1;
//unsigned char lut[]={0xfc, 0x60, 0xda, 0xf2, 0x66, 0xbe, 0xe0, 0xfe,0xf6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e};


//void process();
void scanner();
void init();
void init_t0();
void init_keypad();
void init_uart();
void key_release();
void k();
void buzzer();
void out_debounce();
void spurious_key();
void l1_k();
void out_k();
void debounce();
void init_display();
void tx_uart();
void uart_disp();
unsigned char lut_ascii[]="0123456789ABCDEF";
void uart_delay(unsigned int n);

void isr_t0()interrupt 1 using 0
{
init_t0();
buzzer();
scanner();
}

void main()
{
init();
EA=1;
ds1=0;
while(1)
{
while(key_ready==0);
ds1=key_code;
uart_disp();
tx_uart();
uart_delay(500);
key_release();
}
}

void init()
{
init_keypad();
init_t0();
init_uart();
}

void init_uart()
{
TMOD=0x20;
TH1=0xFD;
TR1=1;
SCON=0x52;
}

void init_keypad()
{
krl1=1;
krl2=1;
krl3=1;
krl4=1;
scan=0;
dcount=33;
krcount=32;
key_ready=0;
nkp=0;
start_buzzer=0;
}
void init_t0()
{
TMOD|=0x01;
TL0=0x66;
TH0=0xFC;
TR0=1;
ET0=1;
}

void scanner()
{
	switch(scan)
	{
	case 0:
					sl1=0;
					sl2=1;
					sl3=1;
					sl4=1;
					
					CY=krl1;
					k();
					scan=1;
					break;	   
			case 1:
					CY=krl2;
					k();
					scan=2;
					break;
			case 2: CY=krl3;
					k();
					scan=3;
					break;
    
	case 3:
					CY=krl4;
					k();
					scan=4;
					break;
			case 4: 
					sl1=1;
					sl2=0;
					sl3=1;
					sl4=1;
					
					CY=krl1;
					k();
					scan=5;
					break;
			case 5: 
					CY=krl2;
					k();
					scan=6;
					break;
			case 6: 
					CY=krl3;
					k();
					scan=7;
					break;
			case 7: 
					
					CY=krl4;
					k();
					scan=8;
					break;
			case 8: 
					sl1=1;
					sl2=1;
					sl3=0;
					sl4=1;
					
					CY=krl1;
					k();
					scan=9;
					break;
			case 9: 
					CY=krl2;
					k();
					scan=10;
					break;
			case 10: 
					CY=krl3;
					k();
					scan=11;
					break;
			case 11: 
					
					CY=krl4;
					k();
					scan=12;
					break;
			case 12: 
					sl1=1;
					sl2=1;
					sl3=1;
					sl4=0;
					
					CY=krl1;
					k();
					scan=13;
					break;
			case 13: 
					CY=krl2;
					k();
					scan=14;
					break;
			case 14: 
					CY=krl3;
					k();
					scan=15;
					break;
			case 15: 
					
					CY=krl4;
					k();
					scan=0;
					break;
		    default:
					scan=0;
					break;	
		}
}
void k()
{
if(key_ready==1)
out_debounce();
else
{
if(dcount==33)
{
if (CY==1)
out_k();
else
{
dcount--;
key_code=scan;
out_k();
}
}
else
debounce();
}
}

void debounce()
{
dcount--;
if(dcount==0)
{
if(CY==1)
spurious_key();
else
{
dcount=33;
key_ready=1;
start_buzzer=1;
out_k();
}
}
else
{
out_k();
}
}

void spurious_key()
{
dcount=33;
out_k();
}

void out_debounce()
{
if(CY==1)
l1_k();
else
krcount=32;
out_k();
}

void l1_k()
{
krcount--;
if(krcount==0)
{
nkp=1;
start_buzzer=0;
krcount=32;
out_k();
}
else
out_k();
}
void out_k()
{
}

void key_release()
{
while(nkp==0);
key_ready=0;
nkp=0;
}

void buzzer()
{
if(start_buzzer==1)
buzz=~buzz;
} 

void tx_uart()
{
while(TI==0);
SBUF= tx_data;
TI=0;
}

void uart_disp()
{
tx_data=lut_ascii[ds1];
}

void uart_delay(unsigned int n)
{
unsigned int k,j;
for(k=0;k<=n; k++)
for(j=0; j<=255; j++);
}