#include <REG51F.H>
void init_uart();
void tx(unsigned char ch2);
unsigned char rx();
unsigned char ch , ch1;
unsigned int i=0;

void main()
{
init_uart();
tx('R');
while(1)
{
ch=rx();
tx(ch);
}
}
void init_uart()
{
SCON=0x52;
TMOD=0x20;
TH1=0xfd;
TR1=1;
}

void tx(unsigned char ch2)
{
while(TI==0);
SBUF=ch2;
TI=0;
}

unsigned char rx()
{
while(RI==0);
ch1=SBUF;
RI=0;
return(ch1);
}
  



