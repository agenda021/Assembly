
  #include<Reg51f.h>
#include<stdio.h>

	sbit sl1=P2^0;			
	sbit sl2=P2^1;
	sbit sl3=P2^2;
	sbit sl4=P2^3;
unsigned int j,n,k;
unsigned char ds1,ds2,ds3,ds4;
unsigned int tx_data; 
unsigned int luk[10]={0xfc,0x60,0xda,0xf2,0x66,0xb6,0xbe,0xe0,0xfe,0xe6};
unsigned char ascii[]="0123456789ABCDEF";
void inc_d();

void init_uart();
void uart_disp();
void uart_tx();
void uart_delay(unsigned int);

void main()
{
init_uart();

ds1=0,ds2=0,ds3=0,ds4=0;
while(1)
{
for(k=0; k<01; k++)
{
uart_disp();
uart_delay(200);
}
inc_d();
}
}

 void init_uart()
 {
 TMOD=0x20;
 TH1=0xFD;
 TR1=1;
 SCON=0x52;
 }
  void inc_d()
{
ds1++;
if(ds1==9+1)
{
ds1=0;
ds2++;
if(ds2==9+1)
{
ds2=0;
ds3++;
if(ds3==9+1)
{
ds3=0;
ds4++;
if(ds4==9+1)
{
ds4=9;
ds3=9;
ds2=9;
ds1=9;
}
}
}
}
}
void uart_disp()
{
	
	tx_data=ascii[ds4];
	uart_tx();
	tx_data=ascii[ds3];
	uart_tx();
	tx_data=ascii[ds2];
	uart_tx();
	tx_data=ascii[ds1];
	uart_tx();
}


void uart_tx()
{  
	while(TI==0);  
    SBUF=tx_data;
	TI=0;
}

	void uart_delay(unsigned int n)
{
		unsigned int k,j;
	
	 	for (k=0;k<=n;k++)
			for (j=0;j<=255;j++);
}


