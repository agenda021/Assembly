	/*STOPWATCH*/
#include <REG51F.H>
#include <intrins.h>

sbit sl1=P2^0;
sbit sl2=P2^1;
sbit sl3=P2^2;
sbit sl4=P2^3;

sbit krl1=P2^4;
sbit krl2=P2^5;
sbit krl3=P2^6;
sbit krl4=P2^7;


//sbit buzz=P1^5;

bit cy, nkp, start_buzzer, key_ready,start_count,ovr_bit;
unsigned char ds1,ds2,ds3,ds4,delay_reg;
unsigned char  key_code, temp ,scan_no,dcount,krcount;
unsigned char ascii_tab[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
//unsigned char look_up[]={0xfc,0x60,0xda,0xf2,0x66,0xb6,0xbe,0xe0,0xfe,0xf6,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xee,0x3e,0x9c,0x7a,0x9e,0x8e};
unsigned int look_up[10]={0xfc,0x60,0xda,0xf2,0x66,0xb6,0xbe,0xe0,0xfe,0xf6};

void isr_t0(); //interrupt routine
//subroutines

void init_keypad();
void init_timer0();

void count_process();
void delay1();
void key_release();
void key_process();
void scanner();
void key_routine();
void out_debounce();


/*---------------------main program----------------------------------*/
void main()
{
	P0=0x00;
	init_timer0();
	init_keypad();

	EA=1;

	ds1=ds2=ds3=ds4=0;
	while(1)
	{
		while(key_ready==1)
		{
			key_process();
			key_release();
		 }
	}
}
/*---------------------subroutines---------------------------------*/

//init_display
/*void init_display()
{
	ds1=ds2=ds3=ds4='9'+2;
} */    
//init_keypad
void init_keypad()
{
	krl1=krl2=krl3=krl4=1;
	scan_no=0;
	key_code=0;
	dcount=33;
	krcount=32;
	key_ready=0;
	nkp=0;
	start_buzzer=0;
	delay_reg=0x0f;
}
//init_timer0
void init_timer0()
{
	TMOD=0x01;
	 TL0=0xf2;
	 TH0=0xf2;
	 TR0=1;
	 ET0=1;
} 
//key_release
void key_release()
{
	while(nkp==1)
	{
		key_ready=0;
		nkp=0;
	}
}
/*---------------------------------key_process---------------------------------*/
void key_process()
{
	if(ascii_tab[key_code]=='A') 
		
		start_count=1; //start
	
	else
	{
		if(ascii_tab[key_code]=='B')
			start_count=0;//stop

		else
		{
			if(ascii_tab[key_code]=='C')//reset

				ds1=ds2=ds3=ds4=0;
		}
	}
}
	
/*-------------------------------interrupt routine-----------------------------*/

void isr_t0(void)interrupt 1 using 1  //interrupt 1 mode 1
{
	delay1();//to enable ovr bit 
	init_timer0();
	scanner();
	if(ovr_bit==1)
	{
		count_process();
		ovr_bit=0;
	}
}
/*-------------------------------------------------------------------------------*/
//delay1
void delay1()
{
	delay_reg--;
	if(delay_reg==0x00)
	{
		delay_reg=0x0f;
		ovr_bit=1;
	}
}
//count_process
void count_process()
{
	if(start_count==1)
	{
		ds1++;
		if(ds1==9+1)
		{
			ds1=0;
			ds2++;
			if(ds2==9+1)
			{
				ds2=0;
				ds3++;
				if(ds3==9+1)
				{
					ds3=0;
					ds4++;
					if(ds4==9+1)
						ds4=0;
				}
			}
		}
	}
}
 //scanner routine
void scanner()
{
  switch(scan_no)
  {
  	case 0:{ 
			 sl1=0;
			 sl2=sl3=sl4=1;
			 P0=look_up[ds1];
			 cy=krl1;
			 key_routine();
			 scan_no++;
			//break;
			}
	case 1:{
			 cy=krl2;
			 key_routine();
			 scan_no++;
			 //break;
			}
    case 2:{
			 cy=krl3;
			 key_routine();
			 scan_no++;
		//	break;
			}
	case 3:{
			 cy=krl4;
			 key_routine();
			 scan_no++;
			 P0=0x00;
			 //break;
			}

	case 4:{ 
			 sl2=0;
			 sl1=sl3=sl4=1;
			 P0=look_up[ds2];
			 cy=krl1;
			 key_routine();
			 scan_no++;
			//break;
			}
	case 5:{
			 cy=krl2;
			 key_routine();
			 scan_no++;
			// break;
			}
    case 6:{
			 cy=krl3;
			 key_routine();
			 scan_no++;
			 //break;
			}
	case 7:{
			 cy=krl4;
			 key_routine();
			 scan_no++;
			 P0=0x00;
			 //break;
			}

	case 8:{ 
			 sl3=0;
			 sl1=sl2=sl4=1;
			 P0=look_up[ds3];
			 cy=krl1;
			 key_routine();
			 scan_no++;
			 //break;
			}
	case 9:{
			 cy=krl2;
			 key_routine();
			 scan_no++;
			 //break;
			}

    case 10:{
			 cy=krl3;
			 key_routine();
			 scan_no++;
			// break;
			}
	case 11:{
			 cy=krl4;
			 key_routine();
			 scan_no++;
			 P0=0x00;
			// break;
			}

	case 12:{ 
			 sl4=0;
			 sl1=sl2=sl3=1;
			 P0=look_up[ds4];
			 cy=krl1;
			 key_routine();
			 scan_no++;
			// break;
			}
	case 13:{
			 cy=krl2;
			 key_routine();
			 scan_no++;
			// break;
			}
    case 14:{
			 cy=krl3;
			 key_routine();
			 scan_no++;
			// break;
			}
	case 15:{
			 cy=krl4;
			 key_routine();
			 scan_no=0;
			 P0=0x00;
			// break;
			}
	}
}
//key_routine
void key_routine()
{
	if(key_ready==0)
	{
		if(dcount==33)
		{
			if(cy==0)
			{
				
				key_code=scan_no;
				dcount--;
			}
			else
				dcount--;
		}
		else
		{
			dcount--;
			if(dcount==0)
			{
				if(cy==0)
				{
					key_ready=start_buzzer=1;
					dcount=33;
				}
				else
				{
					dcount=33;
				}
			}
		}
	}
	else
	{
		out_debounce();
	}
}

//out_debounce_routine
void out_debounce()
{
		krcount--;
		if(krcount==0)
		{
		   if(cy==1)
		   {
			nkp=1;
			start_buzzer=0;
			krcount=32;
			}
			else
			krcount=32;
		}
}





