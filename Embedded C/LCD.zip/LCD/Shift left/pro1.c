#include <REG51F.H>
#include <intrins.h>
sbit back=P0^0;
sbit rs=P0^1;
sbit rw=P0^2;
sbit en=P0^3;
sbit d4=P0^4;
sbit d5=P0^5;
sbit d6=P0^6;
sbit d7=P0^7;

bit tb;
void init_lcd(void);
void delay(unsigned int t);
void lcd_cw(unsigned char);
void lcd_dw(unsigned char);
void busy();
void toggle_e();

void main()
{

P0=0x00;
init_lcd();
lcd_dw('J');
 delay(100);

lcd_dw('E');
delay(100);

lcd_dw('E');
delay(100);

lcd_dw('V');
delay(100);

lcd_dw('A');
delay(100);

lcd_dw('N');
delay(100);
	


while(1)  
{
lcd_cw(0x18);
delay(50);
}

  }
void init_lcd()
{
delay(15);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);
lcd_cw(0x02);  //4bit mode
delay(5);
lcd_cw(0x28);  //set interface length
delay(5);
lcd_cw(0x10);  // move cursor shift display
delay(5);
lcd_cw(0x0e);  // enable display cursor
delay(5);
lcd_cw(0x06);  //cursor move direction
delay(5);
lcd_cw(0x01);  //clear display
delay(5);
back=0;
}

void lcd_cw(unsigned char x)
{
//busy();
rs=0;
rw=0;
P0=((P0&0x0f)|(x&0xf0));
toggle_e();
P0=((P0&0x0f)|((x&0x0f)<<4));
toggle_e();
}

void lcd_dw(unsigned char x)
{
//busy();
rs=1;
rw=0;
P0=((P0&0x0f)|(x&0xf0));
toggle_e();
P0=((P0&0x0f)|((x&0x0f)<<4));
toggle_e();
}

/*void busy()
{
d7=1;
rs=0;
rw=0;
en=1;
_nop_();
_nop_();
tb=d7;
_nop_();
_nop_();
en=0;
if(tb==0); 
else
busy();
}*/  

void toggle_e()
{
en=1;
_nop_();
_nop_();
_nop_();
_nop_();
en=0;
_nop_();
_nop_();
}

void delay(unsigned int t)
{
unsigned int i, j;
for(i=0; i<=t; i++)
{
for(j=0; j<=250; j++);
}

}