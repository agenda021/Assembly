#include <REG51F.H>
#include <intrins.h>
unsigned int i, j, k;
sbit back=P0^0;
sbit rs  =P0^1;
sbit rw  =P0^2;
sbit en  =P0^3;
sbit d4  =P0^4;
sbit d5  =P0^5;
sbit d6  =P0^6;
sbit d7  =P0^7;

unsigned char ds1, ds2, ds3, ds4;
unsigned char ascii[]="0123456789ABCDEF"; 
bit tb;
void decr();
void lcd_disp();
void delay(unsigned int t);
void init_lcd();
void lcd_cw(unsigned char);
void lcd_dw(unsigned char);
void toggle_e();
void disp_sw();


void main()
{
init_lcd();
disp_sw();
ds1=ds2=ds3=ds4=9;
while(1)
{
for(k=0; k<=10; k++)
{
lcd_disp();
delay(1);
}
decr();
}
}


void lcd_disp()
{
lcd_cw(0xc6);
delay(1);
lcd_dw(ascii[ds4]);
delay(1);
lcd_dw(ascii[ds3]);
delay(1);
lcd_dw(ascii[ds2]);
delay(1);
lcd_dw(ascii[ds1]);
delay(1);
}


void disp_sw()
{
lcd_cw(0x80);
delay(10);    
	delay(1);
	lcd_dw(' ');
	delay(1);
	lcd_dw(' ');
	delay(1);
	lcd_dw('D');
	delay(1);
	lcd_dw('0');
	delay(1);
	lcd_dw('W');
	delay(1);
	lcd_dw('N');
	delay(1);
	lcd_dw(' ');
	delay(1);
    lcd_dw('C');
	delay(1);
	lcd_dw('O');
	delay(1);
	lcd_dw('U');
	delay(1);
	lcd_dw('N');
	delay(1);
	lcd_dw('T');
	delay(1);
	lcd_dw('E');
	delay(1);
	lcd_dw('R');
	delay(1);
	lcd_dw(' ');
	delay(1);
}
   
void init_lcd()
{
delay(15);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);
lcd_cw(0x03);
delay(5);
lcd_cw(0x02); // 4 bit mode
delay(5);
lcd_cw(0x28); // set interface length
delay(5);
lcd_cw(0x10);  // move cursor shift display
delay(5);
lcd_cw(0x0e); // enable display cursor
delay(5);
lcd_cw(0x06); // cursor move direction
delay(5);
lcd_cw(0x01); // clear display
delay(5);
back=0;
}

void lcd_cw(unsigned char x)
{
rs=0;
rw=0;
P0=((P0&0x0f)|(x&0xf0));
toggle_e();
P0=((P0&0x0f)|((x&0x0f)<<4));
toggle_e();
}

void lcd_dw(unsigned char x)
{
rs=1;
rw=0;
P0=((P0&0x0f)|(x&0xf0));
toggle_e();
P0=((P0&0x0f)|((x&0x0f)<<4))	;
toggle_e();
}


void toggle_e()
{
en=1;
_nop_();
_nop_();
_nop_();
_nop_();
en=0;
_nop_();
_nop_();
}

void decr()
{
ds1--;
if(ds1==0-1)
{
  ds1=9;
  ds2--;

  if(ds2==0-1)
  {
   ds2=9;
   ds3--;

     if(ds3==0-1)
	 {
	  ds3=9;
	  ds4--;
	    if(ds4==0-1)
	    { ds1=9;
		  ds2=9;
		  ds3=9;
		  ds4=9;
		  }
		  }
		  }
		  }
		  }

void delay(unsigned int t)
{
unsigned int i, j;
for(i=0; i<=t; i++)
{
for(j=0; j<=250; j++);
}
}