#include <REG51F.H>

sbit sl1=P2^0;
sbit sl2=P2^1;
sbit sl3=P2^2;
sbit sl4=P2^3;

sbit krl1=P2^4;
sbit krl2=P2^5;
sbit krl3=P2^6;
sbit krl4=P2^7;

sbit buzz=P1^5;

bit nkp;
bit tb;
bit start_buzzer;
bit key_ready;

unsigned char dcount, krcount, key_code, scan;
unsigned char ds1, ds2, ds3, ds4;

code unsigned char lut[]={0xfc, 0x60, 0xda, 0xf2,0x66, 0xb6, 0xbe, 0xe0, 0xfe, 0xf6, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xee, 0x3e, 0x9c, 0x7a, 0x9e, 0x8e};

void scanner();
void init_t0();
void init_keypad();
void key_release();
void key(void);
void debounce();
void display();

code unsigned char lut_ascii[]={'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A','B','C','D','E','F'};

void main()
{
P0=0x00;
init_t0();
init_keypad();
EA=1;
ds1=ds2=ds3=ds4='0';
while(1)
{
while(key_ready==0)
{
ds1=lut_ascii[key_code];
key_release();
}
}
}

void init_t0()
{
TMOD=0x01;
TH0=0xFC;
TL0=0x67;
TR0=1;
ET0=1;
}



void init_keypad()
{
key_code=0;
scan=0;
krcount=32;
dcount=33;
key_ready=0;
nkp=0;
start_buzzer=0;
}

void isr_t0() interrupt 1 using 1
{
init_t0();
if(start_buzzer==1)
buzz=~(buzz);
scanner();
}

void scanner()
{
if(scan==0)
{
sl1=0;
sl2=sl3=sl4='1';
P0=lut[ds1-'0'];
tb=krl1;
key();
scan++;
 }
 if(scan==1)
 { tb=krl2;
 key();
 scan++;
 }

 if(scan==2)
 tb=krl3;
 key();
 scan++;

 if(scan==3)
 {
 tb=krl4;
 key();
 scan++;
 P0=0x00;
 }

 if(scan==4)
 {
 sl2=0;
 sl1=sl3=sl4=2;
 P0=lut[ds2-'0'];
 tb=krl1;
 key();
 scan++;
 }

 if(scan==5)
 {
 tb=krl2;
 key();
 scan++;
 }

 if(scan==6)
 {
 tb=krl3;
 key();
 scan++;
 }

 if(scan==7)
 {
 tb=krl4;
 key();
 scan++;
 P0=0x00;
 }


 if(scan==8)
 {
 sl3=0;
 sl1=sl2=sl4=1;
 P0=lut[ds3-'0'];
 tb=krl1;
 key();
 scan++;
 }
 if(scan==9)
 {
 tb=krl2;
 key();
 scan++;
 }

if(scan==10)
{
tb=krl3;
key();
scan++;
}

if(scan==11)
{
tb=krl4;
key();
scan++;
P0=0x00;
}

if(scan==12)
{
sl4=0;
sl2=sl3=sl1=1;
P0=lut[ds4-'0'];
tb=krl1;
key();
scan++;
}

if(scan==13)
{
tb=krl2;
key();
scan++;
}

if(scan==14)
{
tb=krl3;
key();
scan++;
}

if(scan==15)
{
tb=krl4;
key();
scan=0;
P0=0x00;
}
}





void key()
{
if(key_ready==0)
{
if(dcount==33)
{
if(tb==0)
{
key_code=scan;
dcount--;
}
else
dcount--;
}
else
{
dcount--;
if(dcount==0)
{
if(tb==0)
{
key_ready=start_buzzer=1;
dcount=33;
}
else
dcount=33;
}
}
}
else
{
debounce();
}
}

void debounce()
{
krcount--;
if(krcount==0)
{
if(tb==1)
{
nkp=1;
start_buzzer=0;
krcount=32;
}
else
krcount=32;
}
}

void key_release()
{
while(nkp==0)
{}
key_ready=0;
nkp=0;
}
