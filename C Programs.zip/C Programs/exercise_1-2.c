/*`hello, world'' */
/*programmer :neeta a patade.*/
/*date:01/04/2009 */
/*Experiment to find out what happens when prints's argument string contains \c, where c is some
character not listed above.*/
#include <stdio.h>


int main ()


{

/* This will compile with a warning and it will just print the letter
	 * 'c' on the screen.
	 */



  printf("Trying to print \c...\n");

}
//success
