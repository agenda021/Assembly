/*Displaying printable characters */
/*programmer :neeta a patade.*/
/*date:01/04/2009 */



/*Exercise 4.2 */
#include <stdio.h>
#include <ctype.h>

int main(void)
{
  char ch = 0;                       /* Character code value */
  for(int i = 0 ; i<128 ; i++)
  {
    ch = (char)i;
    if(ch%2==0)
      printf("\n");
    printf("  %4d    %c",ch,(isgraph(ch) ? ch : ' '));
  }
  printf("\n");
	return 0;
}
//success
