/*Handling monetary values as integers*/
/*programmer :neeta a patade.*/
/*date:01/04/2009 */
/*Exercise 5.3  */
#include <stdio.h>
#include<d
int main(void)
{
  float amounts[5];                     /* Stores data values        */
  long dollars[5];
  long cents[5];

  printf("Enter five monetary values separated by spaces:\n");
  for(int i = 0 ; i<5 ; i++)
    scanf("%f", &amounts[i]);

  for(int i = 0 ; i<5 ; i++)
  {
    dollars[i] = (long)amounts[i];
    cents[i] = (long)(100.0*(amounts[i]-dollars[i]));
  }

  printf("\n");
  for(int i = 0 ; i<5 ; i++)
    printf("  $%d.%02d", dollars[i], cents[i]);

  printf("\n");
  return 0;
}
//delet
