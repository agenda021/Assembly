/*`/*Write a program to print the value of EOF.*/
/*programmer :neeta a patade.*/
/*date:01/04/2009 */


#include <stdio.h>


int main ()


{

printf("EOF = %d\n", EOF);

 }
//success
