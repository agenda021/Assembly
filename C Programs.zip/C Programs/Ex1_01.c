/*Output a name and addresst*/
/*programmer :neeta a patade.*/
/*date:01/04/2009 */
/* Exercise 1.1  */
#include <stdio.h>

int main(void)
{
  printf("\nGeorge Washington");
  printf("\n3200 George Washington Memorial Parkway");
  printf("\nMount Vernon");
  printf("\nVirginia 22121\n");
  return 0;
}
//success
