/*Output a name and address */
/*programmer :neeta a patade.*/
/*date:01/04/2009 */
/* Exercise 1.3 */
#include <stdio.h>

int main(void)
{
  /* The double quotes must appear as the escape sequence \" */
  printf("\n\"It's freezing in here,\" he said coldly.\n");
  return 0;
}
