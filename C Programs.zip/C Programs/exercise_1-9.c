/*/*Write a program to copy its input to its output, replacing each string of one or more blanks by a
single blank.*/

/*programmer :neeta a patade.*/
/*date:01/04/2009 */

#include <stdio.h>


/* Run this program on itself (this file) and the following string "    "
 * will be only one blank long.
 */


int main ()


{

	int	c;


	while ((c = getchar()) != EOF)
 	{


		if (c == ' ')
		{


			putchar(' ');

			while ((c = getchar()) != EOF && c == ' ');


	}

		if (c != EOF)


			putchar(c);


	}

}
//success
