/*/*Verify that the expression getchar() != EOF is 0 or 1.*/
/*programmer :neeta a patade.*/
/*date:01/04/2009 */


#include <stdio.h>


/* Press Ctrl-D (end of file) to obtain 0, or press any key and then <enter>
 * for 1.
 */


int main ()


{

	int	c;


	c = getchar() != EOF;

	printf("c = getchar() != EOF is %d\n", c);

}
//success
