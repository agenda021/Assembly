/*`hello, world'' */
/*programmer :neeta a patade.*/
/*date:01/04/2009 */
/*Run the ``hello, world'' program on your system. Experiment with leaving out parts of the
program, to see what error messages you get.*/

#include <stdio.h>



/* Some C compilers will complain that main() does not have a return type,
 * especially if compiling in strict ANSI C conformance mode, with all
 * warnings turned on.
 */



int main ()


{

 printf("Hello world!\n");

}
